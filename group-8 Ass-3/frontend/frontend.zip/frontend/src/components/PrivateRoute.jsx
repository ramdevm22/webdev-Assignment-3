import React from 'react'

const PrivateRoute = () => {
  return (
    <div>
      
    </div>
  )
}

export default PrivateRoute
