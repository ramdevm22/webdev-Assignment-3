import React from 'react'

const ProductTabs = () => {
  return (
    <div>
      
    </div>
  )
}

export default ProductTabs
