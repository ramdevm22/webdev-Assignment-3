import React from 'react'

const HeartIcon = () => {
  return (
    <div>
      
    </div>
  )
}

export default HeartIcon
