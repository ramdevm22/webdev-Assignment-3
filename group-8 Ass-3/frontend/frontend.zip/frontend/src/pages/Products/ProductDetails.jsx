import React from 'react'

const ProductDetails = () => {
  return (
    <div>
      
    </div>
  )
}

export default ProductDetails
