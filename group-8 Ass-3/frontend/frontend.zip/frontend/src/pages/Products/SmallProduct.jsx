import React from 'react'

const SmallProduct = () => {
  return (
    <div>
      
    </div>
  )
}

export default SmallProduct
