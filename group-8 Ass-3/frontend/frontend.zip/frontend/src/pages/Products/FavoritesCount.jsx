import React from 'react'

const FavoritesCount = () => {
  return (
    <div>
      
    </div>
  )
}

export default FavoritesCount
