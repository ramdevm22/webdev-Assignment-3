import React from 'react'

const Favorites = () => {
  return (
    <div>
      
    </div>
  )
}

export default Favorites
