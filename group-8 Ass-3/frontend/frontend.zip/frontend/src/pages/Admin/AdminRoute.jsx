import React from 'react'

const AdminRoute = () => {
  return (
    <div>
      
    </div>
  )
}

export default AdminRoute
