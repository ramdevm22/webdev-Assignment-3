import React from 'react'

const CategoryList = () => {
  return (
    <div>
      
    </div>
  )
}

export default CategoryList
