import React from 'react'

const ProductUpdate = () => {
  return (
    <div>
      
    </div>
  )
}

export default ProductUpdate
