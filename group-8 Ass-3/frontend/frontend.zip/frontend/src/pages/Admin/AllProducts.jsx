import React from 'react'

const AllProducts = () => {
  return (
    <div>
      
    </div>
  )
}

export default AllProducts
