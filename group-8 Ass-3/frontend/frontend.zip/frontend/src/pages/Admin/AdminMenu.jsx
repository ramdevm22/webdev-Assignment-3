import React from 'react'

const AdminMenu = () => {
  return (
    <div>
      
    </div>
  )
}

export default AdminMenu
