import React from 'react'

const PlaceOrder = () => {
  return (
    <div>
      
    </div>
  )
}

export default PlaceOrder
