import React from 'react'

const Shipping = () => {
  return (
    <div>
      
    </div>
  )
}

export default Shipping
